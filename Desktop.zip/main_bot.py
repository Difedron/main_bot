from __future__ import print_function

import base64
import os.path
import sqlite3
import threading

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from telegram import Update, ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove
from telegram.ext import CallbackContext, Updater, CommandHandler
import quopri

import app_loger

SCOPES = ['https://www.googleapis.com/auth/gmail.readonly', 'https://www.googleapis.com/auth/gmail.modify']
logger = app_loger.get_logger(__name__)
hello = "Hi Battflit team,<br><br>We have received below message:<br>Content:"
account = '<br><br>User Account:'
user_email = '<br>User email:'
field_names = ['id', 'user', 'user email', 'message', 'done']
users_messages_list = list()
current_problem = str()
skipped = list()


def update_database(address):
    try:
        con = sqlite3.connect("clients.db")
        cur = con.cursor()
        cur.execute(f"""UPDATE main SET done = 1 WHERE id = {address}""")
        con.commit()
        con.close()
        logger.info('db updated')
    except Exception as error:
        logger.critical(error)


def get_problem():
    global current_problem
    global skipped
    con = sqlite3.connect("clients.db")
    cur = con.cursor()
    if len(skipped) >= 2:
        data = cur.execute(f"""SELECT * FROM main WHERE done = 0 AND id NOT IN {tuple(skipped)}""").fetchone()
    elif len(skipped) == 1:
        data = cur.execute(f"""SELECT * FROM main WHERE done = 0 and id != {skipped[0]}""").fetchone()
    else:
        data = cur.execute("""SELECT * FROM main WHERE done = 0""").fetchone()
    con.close()
    if data:
        current_problem = data[0]
        return data
    elif not skipped:
        return ''
    else:
        skipped = []
        return get_problem()


def help_func(update: Update):  # функция для /help
    update.message.reply_text("/start - начало работы\n"
                              "/stop - прекратить просмотр сообщений\n"
                              "/done - заявка обработана\n"
                              "/skip - пропустить заявку")


def start(update: Update, context: CallbackContext):
    reply_markup = ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton(text='/done'),
                KeyboardButton(text='/skip'),
            ],
        ],
        resize_keyboard=True,
        one_time_keyboard=True
    )
    text = get_problem()
    if text:
        text_answer = f'user: {text[1]}\nemail: {text[2]}\nmessage: {text[3]}'
    else:
        text_answer = 'все жалобы обработанны'
        logger.info('all replies done')
    update.message.reply_text(
        text=text_answer,
        reply_markup=reply_markup,
    )


def skip(update: Update, context: CallbackContext):
    global skipped
    global current_problem
    if current_problem:
        skipped.append(current_problem)
        text = 'skip'
    else:
        text = ''
    update.message.reply_text(
        text=text,
        reply_markup=ReplyKeyboardRemove(),
    )
    return start(update=update, context=context)


def done(update: Update, context: CallbackContext):
    global current_problem
    if current_problem:
        update_database(address=current_problem)
        text = 'done'
    else:
        text = 'все жалобы обработаны'
    update.message.reply_text(
        text=text,
        reply_markup=ReplyKeyboardRemove(),
    )
    return start(update=update, context=context)


def stop(update: Update, context: CallbackContext):
    update.message.reply_text(
        text='session stops',
        reply_markup=ReplyKeyboardRemove(),
    )


def write_db():
    try:
        con = sqlite3.connect("clients.db")
        cur = con.cursor()
        for user in users_messages_list:
            cur.execute(f"""INSERT INTO main(user, email, message) 
                        VALUES('{user['user']}', '{user['email']}', '{user['message']}')""")
        con.commit()
        con.close()
        logger.info('db updated')
    except Exception as error:
        logger.critical(error)


def read_emails():
    threading.Timer(3600.0, read_emails).start()  # таймер, время указывается в секундах
    creds = None

    if os.path.exists('token.json'):
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)

    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                'credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)

        with open('token.json', 'w') as token:
            token.write(creds.to_json())

    service = build('gmail', 'v1', credentials=creds)

    result = service.users().messages().list(userId='me', q='in:inbox is:unread').execute()

    messages = result.get('messages')

    if messages:
        for msg in messages:
            txt = service.users().messages().get(
                userId='me', id=msg['id'], format='raw').execute()

            subject_txt = service.users().messages().get(
                userId='me', id=msg['id']).execute()

            service.users().messages().modify(userId='me', id=msg['id'],
                                              body={'removeLabelIds': ['UNREAD']}).execute()
            try:
                payload = subject_txt['payload']
                headers = payload['headers']
                for element in headers:
                    if element['name'] == 'Subject':
                        subject = element['value']
                        if 'user message' in subject:
                            text = txt['raw']
                            message = base64.urlsafe_b64decode(text)
                            decode_text = message.decode('utf-8')
                            find_encoding = len('Content-Transfer-Encoding: ')
                            transfer_encoding = decode_text.split('\n')[21][find_encoding:-1]
                            if transfer_encoding == 'quoted-printable':
                                find_quoted = decode_text.find('quoted-printable')
                                find_ending = decode_text[decode_text.find('quoted-printable'):].find('------=_Part') + find_quoted
                                inf_str_0 = decode_text[find_quoted + len('quoted-printable') + 4:find_ending - 2]
                                inf_str = quopri.decodestring(inf_str_0)
                                inf_str = inf_str.decode('utf-8')
                            else:
                                inf_str = decode_text.split('\n')[23]
                            message = inf_str[inf_str.find(
                                hello) + len(hello):inf_str.find(account)]
                            message = message.replace('<br>', '. ')
                            user = inf_str[inf_str.find(
                                account) + len(account):inf_str.find(user_email)]
                            if inf_str.find(user_email) != -1:
                                email = inf_str[inf_str.find(
                                    user_email) + len(user_email):].split('\r')[0]
                            else:
                                email = '-'

                            dictionary_data = dict()
                            dictionary_data['user'] = user
                            dictionary_data['email'] = email
                            dictionary_data['message'] = message
                            users_messages_list.append(dictionary_data)
            except Exception as error:
                logger.error(error)
        write_db()
    logger.info('messages were received')
    users_messages_list.clear()


def start_bot():
    try:
        updater = Updater(
            token='1891781802:AAELq19vS4Y08xV1qUFVCPPJ0mOaSthlAsI',
            use_context=True
        )
        updater.dispatcher.add_handler(CommandHandler("help", help_func))
        updater.dispatcher.add_handler(CommandHandler("start", start))
        updater.dispatcher.add_handler(CommandHandler("stop", stop))
        updater.dispatcher.add_handler(CommandHandler("skip", skip))
        updater.dispatcher.add_handler(CommandHandler("done", done))
        updater.start_polling()
        logger.info('bot starts')
        updater.idle()
    except Exception as error:
        logger.error(error)


if __name__ == '__main__':
    read_emails()
    start_bot()
